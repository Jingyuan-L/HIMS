create definer = root@localhost event update_appointment on schedule
    every '1' DAY
        starts '2020-11-22 00:01:00'
    on completion preserve
    enable
    do
    update patappointment set status='end' where ap_id in (select a.ap_id from patappointment a join outpatient b on a.ap_id = b.ap_id where b.treated_time < now() and a.status='processing' UNION select a.ap_id from patappointment a join inpatient b on a.ap_id = b.ap_id where b.end_time < now() and a.status='processing' UNION select a.ap_id from patappointment a join nurshmpatient b on a.ap_id = b.ap_id where b.end_time < now() and a.status='processing');

