create definer = root@localhost trigger update_room_status
    after update
    on patappointment
    for each row
BEGIN
 IF
  ( old.status != new.status ) and ( old.type = 'inpatient' )
  THEN
   update room set occupied = 0 where room_id = (select b.room_id from patappointment a join inpatient b on a.ap_id = b.ap_id where a.ap_id = new.ap_id);
 END IF;
END;

